from onelogin_aws_login import cli

if __name__ == '__main__':
    cli.login()
